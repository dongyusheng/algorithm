#ifndef __MAIN_H_
#define __MAIN_H_

#include <iostream>
#include <string>
#include <utility>

using std::cout;
using std::cin;
using std::endl;
using std::pair;
using std::string;


#endif __MAIN_H_