#ifndef __PAIRNODE_H_
#define __PAIRNODE_H_


#include "main.h"

template<class K,class E>
struct pairNode
{
	typedef std::pair<const K, E> pairType;

	pairType element;
	struct pairNode<K,E>* next;

	pairNode(const pairType& thePair):element(thePair) {}
	pairNode(const pairType& thePair, struct pairNode<K, E>* theNext) :element(thePair) { this->next = theNext; }
};


#endif __PAIRNODE_H_