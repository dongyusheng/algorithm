#include "hashChains.h"


int main()
{
	hashChains<int, int>* myHashChains = new hashChains<int, int>(11);
	
	myHashChains->insert(std::pair<int, int>(1, 1));
	myHashChains->insert(std::pair<int, int>(2, 2));
	//myHashChains->insert(std::pair<int, int>(4, 4));
	myHashChains->insert(std::pair<int, int>(13, 3));

	std::cout << *myHashChains;

	return 0;
}