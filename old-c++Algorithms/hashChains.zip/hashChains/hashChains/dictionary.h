#ifndef __DICTIONARY_H_
#define __DICTIONARY_H_

#include "main.h"


template<class K,class E>
class dictionary
{
public:
	virtual ~dictionary(){}
	virtual bool empty()const = 0;
	virtual int size()const = 0;
	virtual std::pair<const K, E>* find(const K& theKey)const = 0;
	virtual void erase(const K& theKey) = 0;
	virtual void insert(const std::pair<const K, E>& thePair) = 0;
};


#endif __DICTIONARY_H_