#ifndef __HASHCHAINS_H_
#define __HASHCHAINS_H_

#include "main.h"
#include "hash.h"
#include "sortedChain.h"

template<class K,class E>
class hashChains :public dictionary<K, E>
{
public:
	hashChains(int theDivisor=11);
	~hashChains();
	bool empty()const override;
	int size()const override;
	std::pair<const K, E>* find(const K& theKey)const override;
	void erase(const K& theKey) override;
	void insert(const std::pair<const K, E>& thePair) override;

	void output(std::ostream & out)const;
private:
	sortedChain<K, E>* table;
	hash<K> hash;  //���ؼ���ӳ��Ϊһ������
	int dSize;     //��ϣ���Ĵ�С
	int divisor;   //��ϣ�����ĳ���
};

template<class K, class E>
hashChains<K, E>::hashChains(int theDivisor = 11)
{
	this->divisor = theDivisor;
	this->dSize = 0;

	this->table = new sortedChain<K, E>[theDivisor];
}

template<class K, class E>
hashChains<K, E>::~hashChains()
{
	if (this->table) {
		delete[] this->table;
		this->table = nullptr;
	}
}

template<class K, class E>
bool hashChains<K, E>::empty()const
{
	return (this->dSize == 0);
}

template<class K, class E>
int hashChains<K, E>::size()const
{
	return this->dSize;
}

template<class K, class E>
std::pair<const K, E>* hashChains<K, E>::find(const K& theKey)const
{
	int index = hash(theKey) % this->divisor;
	return this->table[index].find(theKey);
}

template<class K, class E>
void hashChains<K, E>::erase(const K& theKey)
{
	int index = hash(theKey) % this->divisor;
	this->table[index].erase(theKey);
}

template<class K, class E>
void hashChains<K, E>::insert(const std::pair<const K, E>& thePair)
{
	int bucketIndex = hash(thePair.first) % this->divisor;
	int homeSize = this->table[bucketIndex].size();
	this->table[bucketIndex].insert(thePair);

	//���insert���������滻ֵ�����ǲ�����ֵ����ô������Ԫ�ظ���
	if (this->table[bucketIndex].size() > this->dSize) {
		this->dSize++;
	}
}

template<class K, class E>
void hashChains<K, E>::output(std::ostream & out)const
{
	for (int i = 0; i < this->divisor; ++i) {
		if (this->table[i].empty())
			std::cout << "NULL" << std::endl;
		else
			std::cout << this->table[i];
	}
}

template<class K,class E>
std::ostream& operator<<(std::ostream &out,const hashChains<K,E>& theHashChains)
{
	theHashChains.output(out);
	return out;
}

#endif __HASHCHAINS_H_