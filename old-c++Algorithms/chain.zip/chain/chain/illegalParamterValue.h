#ifndef __ILLEGALPARAMTERVALUE
#include "main.h"

class illegalParamterValue
{
public:
	illegalParamterValue(const char* s) :message(s) {}
	illegalParamterValue(string theMessage="Illegal paramter value") {
		message = theMessage;
	}
	const char* what() {
		return message.c_str();
	}
private:
	string message;
};

#endif __ILLEGALPARAMTERVALUE