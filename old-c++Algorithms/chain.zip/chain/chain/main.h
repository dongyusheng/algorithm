#ifndef __MAIN_H

#include <stdio.h>
#include <sstream>
#include <iostream>
#include <string>

using namespace std;

#endif __MAIN_H