#include "chain.h"

int main()
{
	chain<int> *myChain = new chain<int>();
	
	cout << "Current size is" << myChain->size() << endl;
	cout << "All number is ";
	myChain->output(cout);
	cout << endl << endl;

	cout << "Insert 1,2,3"<< endl;
	myChain->insert(0,1);
	myChain->insert(1, 2);
	myChain->insert(2, 3);

	chain<int>::iterator iter = myChain->begin();
	for (; iter != myChain->end(); iter++) {
		cout << *iter<<"  ";
	}
	cout << endl;

	/*cout << "Current size is" << myChain->size() << endl;
	cout << "All number is ";
	myChain->output(cout);
	cout << endl;
	cout << "Index 0 value is "<< myChain->get(0)<< endl;
	cout << "Index 1 value is " << myChain->get(1) << endl;
	cout << "Index 2 value is " << myChain->get(2) << endl;
	cout << "The index if value 1  is " << myChain->indexOf(1) << endl;
	cout << "The index if value 2  is " << myChain->indexOf(2) << endl;
	cout << "The index if value 3  is " << myChain->indexOf(3) << endl;
	cout << endl << endl;

	myChain->earse(1);
	cout << "earse 2"<< endl;
	cout << "Current size is" << myChain->size() << endl;
	cout << "All number is ";
	myChain->output(cout);
	cout << endl;
	cout << "Index 0 value is " << myChain->get(0) << endl;
	cout << "Index 1 value is " << myChain->get(1) << endl;
	cout << "The index if value 1  is " << myChain->indexOf(1) << endl;
	cout << "The index if value 3  is " << myChain->indexOf(3) << endl;
	cout << endl << endl;

	myChain->insert(1,2);
	cout << "Insert 2" << endl;
	cout << "Current size is" << myChain->size() << endl;
	cout << "All number is ";
	myChain->output(cout);
	cout << endl;
	cout << "Index 0 value is " << myChain->get(0) << endl;
	cout << "Index 1 value is " << myChain->get(1) << endl;
	cout << "Index 2 value is " << myChain->get(2) << endl;
	cout << "The index if value 1  is " << myChain->indexOf(1) << endl;
	cout << "The index if value 2  is " << myChain->indexOf(2) << endl;
	cout << "The index if value 3  is " << myChain->indexOf(3) << endl;*/

	return 0;
}