#ifndef __MAIN_H_
#define __MAIN_H_

#include <iostream>
#include <string>

using std::cout;
using std::endl;
using std::cin;
using std::string;
using std::pair;


#endif __MAIN_H_