#include "hashTable.h"

int main()
{
	hashTable<int,int>* myHashTable = new hashTable<int, int>(11);

	myHashTable->insert(std::pair<int,int>(80,1));
	myHashTable->insert(std::pair<int, int>(40, 2));
	myHashTable->insert(std::pair<int, int>(65, 3));

	myHashTable->output(std::cout);
	std::cout << std::endl;

	myHashTable->insert(std::pair<int, int>(58, 4));
	myHashTable->insert(std::pair<int, int>(24, 5));

	myHashTable->output(std::cout);
	std::cout << std::endl;

	myHashTable->insert(std::pair<int, int>(35, 5));
	
	myHashTable->output(std::cout);
	std::cout << std::endl;

	return 0;
}