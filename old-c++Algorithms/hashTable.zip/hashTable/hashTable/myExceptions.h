#ifndef __MYEXCEPTIONS_H_
#define __MYEXCEPTIONS_H_

#include "main.h"

class hashTableFull
{
public:
	hashTableFull(std::string theMessage ="The hash table is full")
	{
		message = theMessage;
	}
	const char* what() {
		return message.c_str();
	}
private:
	std::string message;
};

#endif __MYEXCEPTIONS_H_