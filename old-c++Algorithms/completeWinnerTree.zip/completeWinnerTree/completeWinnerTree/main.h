#ifndef _MAIN_H_

#include <iostream>
#include <string>
#include <stdlib.h>

using std::cin;
using std::cout;
using std::endl;
using std::string;

#endif