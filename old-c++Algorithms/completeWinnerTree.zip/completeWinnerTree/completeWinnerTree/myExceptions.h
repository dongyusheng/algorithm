#ifndef MYEXCEPTIONS_H_

#include "main.h"

class illegalParameterValue
{
private:
	std::string message;
public:
	illegalParameterValue(std::string theMessage = "Illegal Parameter Value") :message(theMessage) {}
	const char *what() { return message.c_str(); }
};

#endif