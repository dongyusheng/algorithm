#include <iostream>
#include <string>
#include <sstream>
#include <iterator>
#include <algorithm>

using namespace::std;

class illegalParameterValue
{
private:
	string message;
public:
	illegalParameterValue() : message("Illegal Parameter Value") {}
	illegalParameterValue(const char* s) :message(s) {}
	const char *what() {
		return message.c_str();
	}
};


template<typename T>
class linearList
{
public:
	virtual ~linearList() {};
	//�����Ա�Ϊ��ʱ����true
	virtual bool empty() const = 0;
	//�������Ա���Ԫ�ظ���
	virtual int size() const = 0;
	//��������theIndex��Ԫ��
	virtual T& get(int theIndex)const = 0;
	//����Ԫ��theElement��һ�γ���ʱ������
	virtual int indexOf(const T& theElement) const = 0;
	//ɾ������ΪtheIndex��Ԫ��
	virtual void earse(int theIndex) = 0;
	//��theElement�������Ա�������ΪtheIndex��λ����
	virtual void insert(int theIndex, const T& theElement) = 0;
	//�����Ա����������out
	virtual void output(ostream& out)const = 0;
};

template<typename T>
class arrayList :public linearList<T>
{
public:
	arrayList(int initialCapacity = 10);  //���캯��
	arrayList(const arrayList<T>& other); //��������
	~arrayList(); //��������

	bool empty()const override;
	int size()const override;
	T& get(int theIndex)const override;
	int indexOf(const T& theElement)const override;
	void earse(int theIndex)override;
	void insert(int theIndex, const T& theElement)override;
	void output(ostream& out)const override;

	//�������������
	int capacity()const;
public:
	class iterator;
	iterator begin() {
		return iterator(element);
	}
	iterator end() {
		return iterator(element + listSize);
	}
	class iterator
	{
	public:
		typedef bidirectional_iterator_tag iterator_category;
		typedef T value_type;
		typedef ptrdiff_t difference_type;
		typedef T* pointer;
		typedef T& reference;
	public:
		iterator(T* thePosition = 0) {
			position = thePosition;
		}
		/*~iterator() {
		//����������������֪��Ϊʲô������
		if (position) {
		delete[] position;
		position = nullptr;
		}
		}*/

		T& operator*()const {
			return *position;
		}
		T*  operator->()const {
			return &*position;
		}

		iterator& operator++() {
			++position;
			return *this;
		}
		iterator operator++(int) {
			iterator old = *this;
			++position;
			return old;
		}

		iterator& operator--() {
			--position;
			return *this;
		}
		iterator operator--(int) {
			iterator old = *this;
			--position;
			return old;
		}

		bool operator==(const iterator other)const {
			return position == other.position;
		}
		bool operator!=(const iterator other)const {
			return position != other.position;
		}
	protected:
		T *position;
	};
protected:
	T *element;      //�洢���Ա���һά����
	int arrayLength; //һλ���������
	int listSize;    //��ǰ���Ա���Ԫ�ظ���
protected:
	void checkIndex(int theIndex)const; //�������theIndex�Ƿ���Ч
};

template<typename T>
void changeLength(T &a, int oldLength, int newLength);

int main()
{
	arrayList<int> list;
	list.insert(0, 1);
	list.insert(1, 2);
	list.insert(2, 3);
	list.insert(3, 4);

	arrayList<int>::iterator iter;
	for (iter = list.begin(); iter != list.end(); ++iter) {
		cout << *iter << "  ";
	}
	cout << "\n" << endl;
	return 0;
}

template<typename T>
void changeLength(T* &a, int oldLength, int newLength)
{
	if (newLength < 0) {
		throw illegalParameterValue("new length must be >=0");
	}

	T *arr = new T[newLength];
	int length = min(oldLength, newLength);
	copy(a, a + length, arr);
	delete[] a;
	a = arr;
}

template<typename T>
arrayList<T>::arrayList(int initialCapacity)
{
	if (initialCapacity < 1) {
		ostringstream s;
		s << "Initial capacity is " << initialCapacity << ",Must be >0";
		throw illegalParameterValue(s.str().c_str());
	}

	arrayLength = initialCapacity;
	element = new T[arrayLength];
	listSize = 0;
}

template<typename T>
arrayList<T>::arrayList(const arrayList<T>& other)
{
	arrayLength = other.arrayLength;
	listSize = other.listSize;

	element = new T[arrayLength];
	copy(other.element, other.element + listSize, element);
}

template<typename T>
arrayList<T>::~arrayList()
{
	if (element) {
		delete[] element;
		element = nullptr;
	}
}

template<typename T>
bool arrayList<T>::empty()const
{
	return listSize == 0;
}

template<typename T>
int arrayList<T>::size()const
{
	return listSize;
}

template<typename T>
int arrayList<T>::capacity()const
{
	return arrayLength;
}

template<typename T>
void arrayList<T>::checkIndex(int theIndex)const
{
	if ((theIndex<0) || (theIndex >= arrayLength)) {
		ostringstream s;
		s << "index=" << theIndex << ",size=" << arrayLength;
		throw illegalParameterValue(s.str().c_str());
	}
}

template<typename T>
T& arrayList<T>::get(int theIndex)const
{
	checkIndex(theIndex);

	return element[theIndex];
}

template<typename T>
int arrayList<T>::indexOf(const T& theElement)const
{
	int index;
	//find�ɹ����ز��ҵĵ�����λ�ã�ʧ�ܷ��ز���2
	index = (int)(find(element, element + listSize, theElement) - element);
	//���û���ҵ�
	if (index == listSize) {
		return -1;
	}
	else
		return index;
}

template<typename T>
void arrayList<T>::earse(int theIndex)
{
	checkIndex(theIndex);

	copy(element + theIndex + 1, element + listSize, element + theIndex);

	if (listSize < (arrayLength / 4)) {
		changeLength(element, arrayLength, arrayLength / 2);
	}

	element[--listSize].~T();
}

template<typename T>
void arrayList<T>::insert(int theIndex, const T& theElement)
{
	if ((theIndex<0) || (theIndex>listSize)) {
		ostringstream s;
		s << "index=" << theIndex << ",size=" << arrayLength;
		throw illegalParameterValue(s.str().c_str());
	}

	if (listSize == arrayLength) {
		changeLength(element, arrayLength, arrayLength * 2);
		arrayLength *= 2;
	}

	//�Ḵ��ǰ��������������ָ�������С�������������Ŀ�����еĽ���������
	copy_backward(element + theIndex, element + listSize, element + listSize + 1);
	element[theIndex] = theElement;
	listSize++;
}

template<typename T>
void arrayList<T>::output(ostream& out)const
{
	copy(element, element + listSize, ostream_iterator<T>(out, "  "));
}

template<typename T>
ostream& operator<<(ostream& out, const arrayList<T>& x)
{
	x.output(out);
	return out;
}
