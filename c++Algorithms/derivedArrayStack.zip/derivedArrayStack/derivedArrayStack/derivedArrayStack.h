#ifndef __DERIVEDARRAYSTACK_H
#define __DERIVEDARRAYSTACK_H

#include "main.h"
#include "arrayList.h"
#include "stack.h"
#include "myExceptions.h"

template<typename T>
class derivedArrayStack :private arrayList<T>, public stack<T>
{
public:
	derivedArrayStack(int initialCapaticy = 10) :arrayList<T>(initialCapaticy){}

	bool empty()const;
	int size()const;
	T& top();
	void pop();
	void push(const T& theElement);
};

template<typename T>
bool derivedArrayStack<T>::empty()const 
{
	return arrayList<T>::empty();
}

template<typename T>
int derivedArrayStack<T>::size()const 
{
	return arrayList<T>::size();
}

template<typename T>
T& derivedArrayStack<T>::top() 
{
	if (arrayList<T>::empty())
		throw stackEmpty();
	return get(arrayList<T>::size() - 1);
}

/*template<typename T>
T& derivedArrayStack<T>::top()
{
	try {
		return get(arrayList<T>::size() - 1);
	}
	catch (illegalParameterValue) {
		throw stackEmpty();
	}
}*/

template<typename T>
void derivedArrayStack<T>::pop()
{
	if (arrayList<T>::empty()) {
		throw stackEmpty();
	}

	earse(arrayList<T>::size() - 1);
}

/*template<typename T>
void derivedArrayStack<T>::pop()
{
	try {
		earse(arrayList<T>::size() - 1);
	}
	catch (illegalParameterValue) {
		throw stackEmpty();
	}
}*/

template<typename T>
void derivedArrayStack<T>::push(const T& theElement)
{
	insert(arrayList<T>::size(), theElement);
}

#endif