#include "derivedArrayStack.h"

int main()
{
	derivedArrayStack<int> *p = new derivedArrayStack<int>();
	p->pop();
	/*p->push(1);
	p->push(2);
	p->push(3);
	cout << "Size:"<< p->size()<<endl;
	cout <<"Top:" << p->top()<<endl;

	p->pop();
	cout << "Pop" << endl;
	cout << "Top:" << p->top() << endl;
	cout << "Size:" << p->size() << endl;*/

	return 0;
}