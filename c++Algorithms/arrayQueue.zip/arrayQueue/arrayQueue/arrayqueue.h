#ifndef __ARRAYQUEUE_H_
#define __ARRAYQUEUE_H_

#include "main.h"
#include "queue.h"
#include "myExceptions.h"

template<class T>
class arrayQueue :public queue<T>
{
public:
	arrayQueue(int initialCapacity=10);
	~arrayQueue();
	bool empty()const override;
	int size()const override; 
	T& front() override;
	T& back() override;
	void pop() override;
	void push(const T& theElement) override;

	void showQueue(std::ostream &s)const;
private:
	int queueFront;
	int queueBack;
	int arrayLength;
	T *element;
};

template<class T>
arrayQueue<T>::arrayQueue(int initialCapacity = 10)
{
	if (initialCapacity <= 0) {
		std::ostringstream s;
		s << "The initialCapacity is " << initialCapacity << ",must bt >0";
		throw illegalParameterValue(s.str().c_str());
	}

	this->element = new T[initialCapacity];
	this->arrayLength = initialCapacity;
	this->queueFront = 0;
	this->queueBack = 0;
}

template<class T>
arrayQueue<T>::~arrayQueue() 
{
	if (element){
		delete[] element;
		element = nullptr;
	}
}

template<class T>
bool arrayQueue<T>::empty()const
{
	return (this->queueBack == this->queueFront);
}

template<class T>
int arrayQueue<T>::size()const
{
	return ((this->queueBack - this->queueFront + this->arrayLength) % this->arrayLength);
}

template<class T>
T& arrayQueue<T>::front()
{
	if (empty())
		throw queueEmpty();
	return this->element[(this->queueFront + 1) % this->arrayLength];
}

template<class T>
T& arrayQueue<T>::back()
{
	if (empty())
		throw queueEmpty();
	return this->element[this->queueBack];
}

template<class T>
void arrayQueue<T>::pop()
{
	if (empty())
		throw queueEmpty();
	this->queueFront = (this->queueFront + 1) % this->arrayLength;
	this->element[this->queueFront].~T();
}

template<class T>
void arrayQueue<T>::push(const T& theElement)
{
	if (((this->queueBack + 1) % this->arrayLength) == this->queueFront) {
		T* newQueue = new T[2 * this->arrayLength];

		int start = (this->queueFront + 1) % this->arrayLength;
		if (start < 2)
			copy(this->element + start, this->element + start + this->arrayLength - 1, newQueue);
		else
		{  
			copy(this->element + start, this->element + this->arrayLength, newQueue);
			copy(this->element, this->element + this->queueBack + 1, newQueue + this->arrayLength - start);
		}

		
		this->queueFront = 2 * this->arrayLength - 1;
		this->queueBack = this->arrayLength - 2;
		this->arrayLength *= 2;
		this->element = newQueue;
	}
	this->queueBack = (this->queueBack + 1) % this->arrayLength;
	this->element[this->queueBack] = theElement;
}

template<class T>
void arrayQueue<T>::showQueue(std::ostream &s)const
{
	if (empty())
		throw queueEmpty();

	int index = (this->queueFront + 1) % this->arrayLength;
	for (; index != this->queueBack; index = ((index+1) % this->arrayLength)) {
		s << this->element[index]<<" ";
	}
}

#endif __ARRAYQUEUE_H_