#ifndef __MAIN_H_
#define __MAIN_H_

#include <iostream>
#include <string>
#include <sstream>
#include <algorithm>
#include <numeric>

using std::cout;
using std::cin;
using std::endl;
using std::string;
using std::copy;

#endif __MAIN_H_