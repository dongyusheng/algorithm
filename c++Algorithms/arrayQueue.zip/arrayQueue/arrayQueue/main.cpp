#include "arrayQueue.h"

int main()
{
	arrayQueue<int>* myQueue = new arrayQueue<int>(4);

	myQueue->push(1);
	myQueue->push(2);
	myQueue->push(3);
	myQueue->push(4);
	std::cout << "Capacity is " << myQueue->size() << std::endl;
	myQueue->showQueue(std::cout);
	std::cout<<std::endl;

	myQueue->pop();
	std::cout << "Capacity is " << myQueue->size() << std::endl;
	myQueue->showQueue(std::cout);
	std::cout << std::endl;

	myQueue->push(5);
	myQueue->push(6);
	std::cout << "Capacity is " << myQueue->size() << std::endl;
	myQueue->showQueue(std::cout);
	std::cout << std::endl;

	return 0;
}