#pragma once
#include <iostream>
#include <string>
#include <sstream>
#include <algorithm>

using namespace std;