#include "main.h"
#include "matrix.h"

int main()
{
	matrix<int> m(3, 3);

	for (int i = 1; i <= m.rows(); i++) {
		for (int j = 1; j <= m.columns(); j++) {
			m(i, j) = 1;
		}
	}
	cout << "m is:" << endl;
	cout << m<<endl;

	cout << "matrix + 1:"<< endl;
	m += 1;
	cout << m << endl;

	matrix<int> m2(m);
	cout << "m2 is:" << endl;
	cout << m2 << endl;


	cout <<"m+m2=:" << endl;
	cout << m+m2<< endl;

	cout << "m*m2=:" << endl;
	cout << m * m2 << endl;
	return 0;
}