#ifndef __STACK_H
#define __STACK_H

#include "main.h"

template<class T>
class stack
{
public:
	virtual ~stack() = default;
	virtual bool empty()const = 0;
	virtual int size()const = 0;
	virtual T& top()const = 0;
	virtual void pop() = 0;
	virtual void push(const T& theElement) = 0;
};

#endif __STACK_H