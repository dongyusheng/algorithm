#ifndef __MYEXCEPTIONS_H
#define __MYEXCEPTIONS_H

#include "main.h"

class illegalParameterValue
{
	std::string message;
public:
	illegalParameterValue(const char *theMessage = "Illegal Parameter Value") :message(theMessage) {}
	const char *what() {
		return message.c_str();
	}
};

class stackEmpty
{
public:
	stackEmpty(string theMessage = "Invalid operation on empty stack")
	{
		message = theMessage;
	}
	const char *what() {
		return message.c_str();
	}
private:
	std::string message;
};

#endif __MYEXCEPTIONS_H