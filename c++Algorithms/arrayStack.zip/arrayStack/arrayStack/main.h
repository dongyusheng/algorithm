#ifndef __MAIN_H_
#define __MAIN_H_

#include <stdio.h>
#include <iostream>
#include <sstream>
#include <string>
#include <stdlib.h>
#include <algorithm>
#include <numeric>

using std::cout;
using std::endl;
using std::string;
using std::copy;
using std::min;


#endif __MAIN_H