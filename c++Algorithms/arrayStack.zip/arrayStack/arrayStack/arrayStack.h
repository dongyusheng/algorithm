#ifndef __ARRAYSTACK_H
#define __ARRAYSTACK_H

#include "main.h"
#include "stack.h"
#include "myExceptions.h"

template<class T>
void changeLength(T *theElement,int oldSize, int newSize);

template<class T>
class arrayStack :public stack<T>
{
public:
	arrayStack(int initialCapacity = 10);
	~arrayStack();

	bool empty()const override;
	int size()const override;
	T& top()const override;
	void pop()override;

	void push(const T& theElement)override;
private:
	int arrayLength;
	int stackTop;
	T *element;
};

template<class T>
arrayStack<T>::arrayStack(int initialCapacity = 10)
{
	if (initialCapacity < 1) {
		std::ostringstream s;
		s << "You initialCapacity is "<< initialCapacity <<",but the initialCapacity must be >0";
		throw illegalParameterValue(s.str().c_str());
	}
	element = new T[initialCapacity];
	arrayLength = initialCapacity;
	stackTop = -1;
}

template<class T>
arrayStack<T>::~arrayStack()
{
	delete[] element;
	element = nullptr;
}

template<class T>
bool arrayStack<T>::empty()const
{
	return stackTop == -1;
}

template<class T>
int arrayStack<T>::size()const
{
	return stackTop + 1;
}

template<class T>
T& arrayStack<T>::top()const
{
	if (stackTop == -1)
		throw stackEmpty();

	return element[stackTop];
}

template<class T>
void arrayStack<T>::pop()
{
	if (stackTop == -1)
		throw stackEmpty();
	element[stackTop--].~T();
}

template<class T>
void arrayStack<T>::push(const T& theElement)
{
	if (stackTop >= arrayLength - 1) {
		changeLength(element, arrayLength, arrayLength * 2);
		arrayLength *= 2;
	}

	element[++stackTop] = theElement;
}

template<class T>
void changeLength(T *theElement, int oldSize, int newSize)
{
	if (newSize < 0)
		throw illegalParameterValue("New size must be >=0");

	int minSize = min(oldSize, newSize);

	T *tempElement = new T[newSize];
	copy(theElement, theElement + minSize, tempElement);

	if (theElement)
		delete[] theElement;
	theElement = tempElement;
}

#endif __ARRAYSTACK_H