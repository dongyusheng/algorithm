#include "arrayStack.h"
#include "main.h"


int main()
{
	arrayStack<int> *myStack = new arrayStack<int>(5);

	myStack->push(1);
	myStack->push(2);
	myStack->push(2);

	std::cout << "Current size:"<<myStack->size() <<std::endl;
	std::cout << "Top:" << myStack->top() << std::endl;

	myStack->pop();

	std::cout << "Current size:" << myStack->size() << std::endl;
	std::cout << "Top:" << myStack->top() << std::endl;

	return 0;
}