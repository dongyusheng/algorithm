#ifndef __MYEXCEPTIONS_H
#define __MYEXCEPTIONS_H

#include "main.h"

class illegalParameterValue
{
	string message;
public:
	illegalParameterValue(const char *theMessage = "Illegal Parameter Value") :message(theMessage) {}
	const char *what() {
		return message.c_str();
	}
};

class queueEmpty
{
public:
	queueEmpty(string theMessage = "Invalid operation on empty queue")
	{
		message = theMessage;
	}
	const char *what() {
		return message.c_str();
	}
private:
	string message;
};

#endif