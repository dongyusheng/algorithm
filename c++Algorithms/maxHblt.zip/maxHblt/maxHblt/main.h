#ifndef __MAIN_H_
#define __MAIN_H_

#include <iostream>
#include <string>
#include <queue>

using std::cout;
using std::endl;
using std::cin;
using std::string;
using std::pair;
using std::queue;

#endif