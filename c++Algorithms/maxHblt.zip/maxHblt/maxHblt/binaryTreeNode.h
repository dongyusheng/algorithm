#ifndef __BINARYTREENODE_H_
#define __BINARYTREENODE_H_

#include "main.h"

template<typename T>
struct binaryTreeNode
{
	T element;
	struct binaryTreeNode<T>* leftChild, 
							*rightChild;
	binaryTreeNode() { this->leftChild = this->rightChild = nullptr; }
	
	binaryTreeNode(const T& theElement) :element(theElement) {
		this->leftChild = this->rightChild = nullptr;
	}

	binaryTreeNode(const T& theElement,const struct binaryTreeNode<T>* theLeftChild,
		const struct binaryTreeNode<T>* theRightChild) :element(theElement) {
		this->leftChild = theLeftChild;
		this->rightChild = theRightChild;
	}
};


#endif