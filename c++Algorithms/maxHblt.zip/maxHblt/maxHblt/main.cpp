#include "maxHblt.h"

int main()
{
	maxHblt<int>* myMaxHblt = new maxHblt<int>();
	/*myMaxHblt->push(7);
	myMaxHblt->push(5);
	myMaxHblt->push(10);
	myMaxHblt->push(3);*/
	int arr[5] = { 0,3,7,10,3 };
	myMaxHblt->initialize(arr,4);

	myMaxHblt->preOrderOutput();
	std::cout << std::endl;
	myMaxHblt->inOrderOutput();
	std::cout << std::endl;
	myMaxHblt->postOrderOutput();
	std::cout << std::endl;
	std::cout << std::endl;

	myMaxHblt->pop();

	myMaxHblt->preOrderOutput();
	std::cout << std::endl;
	myMaxHblt->inOrderOutput();
	std::cout << std::endl;
	myMaxHblt->postOrderOutput();
	std::cout << std::endl;
	std::cout << std::endl;

	return 0;
}