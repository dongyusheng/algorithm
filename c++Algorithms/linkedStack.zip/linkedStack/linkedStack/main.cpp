#include "linkedStack.h"

int main()
{
	linkedStack<int> *myStack = new linkedStack<int>;

	myStack->push(1);
	myStack->push(2);
	myStack->push(3);

	std::cout << "Current size:" << myStack->size() << std::endl;
	std::cout << "Top:" << myStack->top() << std::endl;

	myStack->pop();

	std::cout << "Current size:" << myStack->size() << std::endl;
	std::cout << "Top:" << myStack->top() << std::endl;

	return 0;
}