#ifndef __LINKEDSTACK_H_
#define __LINKEDSTACK_H_

#include "main.h"
#include "myExceptions.h"
#include "stack.h"
#include "chainNode.h"

template<class T>
class linkedStack :public stack<T>
{
public:
	linkedStack(int initialCapacity = 10);
	~linkedStack();

	bool empty()const override;
	int size()const override;
	T& top()override;
	void pop()override;
	void push(const T& theElement)override;
private:
	chainNode<T> *stackTop;
	int stackSize;
};

template<class T>
linkedStack<T>::linkedStack(int initialCapacity = 10)
{
	stackTop = nullptr;
	stackSize = 0;
}

template<class T>
linkedStack<T>::~linkedStack()
{
	while (stackTop!=nullptr) {
		chainNode<T> *tempNode = stackTop->next;
		delete stackTop;
		stackTop = tempNode;
	}
}

template<class T>
bool linkedStack<T>::empty()const
{
	return stackSize == 0;
}

template<class T>
int linkedStack<T>::size()const
{
	return stackSize;
}

template<class T>
T& linkedStack<T>::top()
{
	if (stackSize <= 0) {
		throw stackEmpty();
	}

	return stackTop->element;
}

template<class T>
void linkedStack<T>::pop()
{
	if (stackSize <= 0) {
		throw stackEmpty();
	}

	chainNode<T>* tempNode = stackTop->next;
	delete stackTop;
	stackTop = tempNode;
	stackSize--;
}

template<class T>
void linkedStack<T>::push(const T& theElement)
{
	stackTop = new chainNode<T>(theElement, stackTop);
	stackSize++;
}

#endif