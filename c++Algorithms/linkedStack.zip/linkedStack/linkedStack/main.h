#ifndef __MAIN_H_
#define __MAIN_H_

#include <stdio.h>
#include <stdlib.h>
#include <sstream>
#include <iostream>
#include <string>
#include <algorithm>
#include <numeric>
#include <iterator>

using std::cout;
using std::endl;
using std::string;

#endif