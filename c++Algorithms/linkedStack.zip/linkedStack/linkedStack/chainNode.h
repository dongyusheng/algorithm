#ifndef __CHAINODE_H
#define __CHAINODE_H

#include "main.h"

template<class T>
struct chainNode
{
	chainNode() = default;
	chainNode(const T& theElement) {
		element = theElement;
	}
	chainNode(const T& theElement, chainNode<T> *theNext) {
		element = theElement;
		next = theNext;
	}
	T element;
	chainNode<T> *next;
};

#endif  __CHAINODE_H