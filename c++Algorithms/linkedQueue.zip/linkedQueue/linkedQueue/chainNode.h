#ifndef __CHAINNODE_
#define __CHAINNODE_

template<class T>
struct chainNode
{
	T element;
	struct chainNode<T>* next;
	chainNode() = default;
	chainNode(const T& theElement)
	{
		this->element = theElement;
		this->next = nullptr;
	}
	chainNode(const T& theElement, chainNode<T>* next)
	{
		this->element = theElement;
		this->next = next;
	}
};


#endif __CHAINNODE_