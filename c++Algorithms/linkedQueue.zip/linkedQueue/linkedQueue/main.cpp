#include "linkedQueue.h"


int main()
{
	linkedQueue<int>* myQueue = new linkedQueue<int>();

	myQueue->push(1);
	myQueue->push(2);
	myQueue->push(3);
	std::cout << "Current Size " << myQueue->size() << std::endl;
	myQueue->showQueue(std::cout);
	std::cout << std::endl;

	myQueue->pop();
	std::cout << "Current Size " << myQueue->size() << std::endl;
	myQueue->showQueue(std::cout);
	std::cout << std::endl;

	return 0;
}