#ifndef __LINKEDQUEUE_H_
#define __LINKEDQUEUE_H_

#include "main.h"
#include "chainNode.h"
#include "queue.h"
#include "myExceptions.h"

template<class T>
class linkedQueue :public queue<T>
{
public:
	linkedQueue(int initialCapacity = 10);
	~linkedQueue();

	bool empty()const override;
	int size()const override;
	T& front() override;
	T& back() override;
	void pop() override;
	void push(const T& theElement) override;

	void showQueue(std::ostream &s)const;
private:
	chainNode<T>* queueFront;
	chainNode<T>* queueBack;
	int queueSize;
};

template<class T>
linkedQueue<T>::linkedQueue(int initialCapacity = 10)
{
	queueFront = queueBack = nullptr;
	queueSize = 0;
}

template<class T>
linkedQueue<T>::~linkedQueue() 
{
	chainNode<T>* temp;
	while (queueFront) {
		temp = queueFront->next;
		delete queueFront;
		queueFront = temp;
	}
}

template<class T>
bool linkedQueue<T>::empty()const
{
	return queueSize==0;
}

template<class T>
int linkedQueue<T>::size()const
{
	return queueSize;
}

template<class T>
T& linkedQueue<T>::front()
{
	if (queueSize == 0)
		throw queueEmpty();
	return queueFront->element;
}

template<class T>
T& linkedQueue<T>::back()
{
	if (queueSize == 0)
		throw queueEmpty();
	return queueBack->element;
}

template<class T>
void linkedQueue<T>::pop()
{
	if (queueSize == 0)
		throw queueEmpty();
	chainNode<T>* tempNode = queueFront->next;
	delete queueFront;
	queueFront = tempNode;
	queueSize--;
}

template<class T>
void linkedQueue<T>::push(const T& theElement)
{
	chainNode<T> *tempNode = new chainNode<T>(theElement,NULL);

	if (queueSize == 0)
		queueFront = tempNode;
	else
		queueBack->next = tempNode;
	queueBack = tempNode;

	queueSize++;
}

template<class T>
void linkedQueue<T>::showQueue(std::ostream &s)const
{
	if (queueSize == 0)
		return;

	chainNode<T>* tempNode = queueFront;
	while (tempNode) {
		s << tempNode->element<<" ";
		tempNode = tempNode->next;
	}
}

#endif __LINKEDQUEUE_H_