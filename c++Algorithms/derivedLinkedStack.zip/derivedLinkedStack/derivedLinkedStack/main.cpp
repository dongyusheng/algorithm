#include "derivedLinkedStack.h"

int main()
{
	derivedLinkedStack<int> *myStack = new derivedLinkedStack<int>(5);

	myStack->push(1);
	myStack->push(2);
	myStack->push(3);

	std::cout << "Current size:" << myStack->size() << std::endl;
	std::cout << "Top:" << myStack->top() << std::endl;

	myStack->pop();

	std::cout << "Current size:" << myStack->size() << std::endl;
	std::cout << "Top:" << myStack->top() << std::endl;

	return 0;
}