#ifndef __CHAIN_H_
#define __CHAIN_H_

#include "linearList.h"
#include "main.h"

template<typename T>
struct chainNode
{
	T element;
	chainNode<T> *next;

	chainNode() {}
	chainNode(const T& element) {
		this->element = element;
	}

	chainNode(const T& element, chainNode<T>* next) {
		this->element = element;
		this->next = next;
	}
};

template<typename T>
class chain :public linearList<T>
{
public:
	chain(int initialCapacity = 10);
	chain(const chain<T>& other);
	~chain();

	bool empty() const;
	int size() const;
	T& get(int theIndex)const override;
	int indexOf(const T& theElement)const override;
	void earse(int theIndex)override;
	void insert(int theIndex, const T& theElement)override;
	void output(std::ostream& out)const override;

private:
	void checkIndex(int theIndex)const;
private:
	chainNode<T>* firstNode;
	int listSize;
};

template<typename T>
chain<T>::chain(int initialCapacity = 10)
{
	if (initialCapacity <= 0) {
		std::ostringstream s;
		s << "Initial Capacity is " << initialCapacity << ",Must >=1";
		throw illegalParameterValue(s.str().c_str());
	}

	this->firstNode = nullptr;
	this->listSize = 0;
}

template<typename T>
chain<T>::chain(const chain<T>& other)
{
	this->listSize = other.listSize;
	if (this->listSize == 0) {
		this->firstNode = nullptr;
		this->listSize = 0;
	}

	chainNode<T>* otherNode = other.firstNode;

	this->firstNode = new chainNode<T>(otherNode->element);
	chainNode<T>* tempNode = this->firstNode;

	while (otherNode->next)
	{
		tempNode->next = new chainNode<T>(otherNode->next->element);
		tempNode = tempNode->next;
		otherNode = otherNode->next;
	}
	tempNode->next = nullptr;
}

template<typename T>
chain<T>::~chain()
{
	chainNode<T> *temp = firstNode;
	while (temp) {
		firstNode = firstNode->next;
		delete temp;
		temp = firstNode;
	}

	/*��ʽ��
	while (firstNode) {
	chainNode<T> *temp = firstNode->next;
	delete firstNode;
	firstNode = temp;
	}
	*/
}

template<typename T>
void chain<T>::checkIndex(int theIndex)const
{
	if ((theIndex<0) || (theIndex >= listSize)) {
		std::ostringstream s;
		s << "List size is " << listSize << ",theIndex is " << theIndex;
		throw illegalParameterValue(s.str().c_str());
	}
}

template<typename T>
bool chain<T>::empty() const
{
	return (listSize == 0);
}

template<typename T>
int chain<T>::size() const
{
	return listSize;
}

template<typename T>
T& chain<T>::get(int theIndex)const
{
	checkIndex(theIndex);

	int index = 0;
	chainNode<T> *tempNode = firstNode;
	while (index != theIndex) {
		tempNode = tempNode->next;
		index++;
	}

	return tempNode->element;
}

template<typename T>
int chain<T>::indexOf(const T& theElement) const
{
	chainNode<T> *tempNode = firstNode;
	for (int i = 0; i < listSize; ++i) {
		if (tempNode->element == theElement) {
			return i;
		}
		tempNode = tempNode->next;
	}
	return -1;

	/*��ʽ��
	chainNode<T> *tempNode = firstNode;
	int index = 0;
	while ((tempNode != nullptr) &&(tempNode->element!= theElement)) {
	tempNode = tempNode->next;
	++index;
	}
	if (tempNode == nullptr) {
	return -1;
	}
	return index;
	*/
}

template<typename T>
void chain<T>::earse(int theIndex)
{
	checkIndex(theIndex);

	chainNode<T> *deleteNode;

	//�����ͷ���
	if (theIndex == 0) {
		deleteNode = firstNode;
		firstNode = firstNode->next;
	}
	else {
		int index = 0;
		chainNode<T> *tempNode = firstNode;

		while (index<theIndex - 1) {
			tempNode = tempNode->next;
		}
		deleteNode = tempNode->next;
		tempNode->next = tempNode->next->next;
	}

	delete deleteNode;
	deleteNode = nullptr;
	listSize--;
}

template<typename T>
void chain<T>::insert(int theIndex, const T& theElement)
{
	if ((theIndex<0) || (theIndex>listSize)) {
		std::ostringstream s;
		s << "List size is " << listSize << ",theIndex is " << theIndex;
		throw illegalParameterValue(s.str().c_str());
	}

	//����ǲ���ͷ���
	if (theIndex == 0) {
		firstNode = new chainNode<T>(theElement, firstNode);
	}
	else {
		int index = 0;
		chainNode<T> *temptNode = firstNode;

		while (index < theIndex - 1) {
			temptNode = temptNode->next;
			index++;
		}
		temptNode->next = new chainNode<T>(theElement, temptNode->next);
	}

	listSize++;
}

template<typename T>
void chain<T>::output(std::ostream& out)const
{
	for (chainNode<T>* tempNode = firstNode; tempNode != nullptr; tempNode = tempNode->next) {
		out << tempNode->element << "  ";
	}
}

#endif __CHAIN_H_
