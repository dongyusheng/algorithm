#ifndef __EXCEPTIONS_H
#define __EXCEPTIONS_H

#include "main.h"

class illegalParameterValue
{
	string message;
public:
	illegalParameterValue(const char *theMessage = "Illegal Parameter Value") :message(theMessage) {}
	const char *what() {
		return message.c_str();
	}
};

class stackEmpty
{
public:
	stackEmpty(string theMessage ="Invalid operation on empty stack")
	{
		message = theMessage;
	}
	const char *what() {
		return message.c_str();
	}
private:
	string message;
};

#endif