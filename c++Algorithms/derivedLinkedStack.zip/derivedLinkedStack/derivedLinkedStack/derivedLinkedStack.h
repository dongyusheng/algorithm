#ifndef __DERIVEDLINKEDSTACK_
#define __DERVIEDLINKEDSTACK_

#include "main.h"
#include "chain.h"
#include "stack.h"
#include "myExceptions.h"

template<class T>
class derivedLinkedStack :private chain<T>, public stack<T>
{
public:
	derivedLinkedStack(int initialCapacity = 10) :chain<T>(initialCapacity) {}
	bool empty()const override {
		return chain<T>::empty();
	}
	int size()const override {
		return chain<T>::size();
	}
	T& top() override{
		return chain<T>::get(0);
	}
	void pop() override {
		try { 
			earse(0); 
		}
		catch (illegalParameterValue) {
			throw stackEmpty();
		}
	}
	void push(const T& theElement) override{
		try {
			insert(0, theElement);
		}
		catch (illegalParameterValue) {
			throw stackEmpty();
		}
	}
};

#endif __DERVIEDLINKEDSTACK_