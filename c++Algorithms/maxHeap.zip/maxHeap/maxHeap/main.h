#ifndef __MAIN_H_
#define __MAIN_H_

#include <iostream>
#include <string.h>
#include <algorithm>
#include<iterator>

using std::cout;
using std::cin;
using std::endl;
using std::string;
using std::min;
using std::copy;
using std::ostream_iterator;

#endif __MAIN_H_