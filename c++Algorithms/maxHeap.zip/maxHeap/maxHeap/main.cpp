#include "maxHeap.h"

int main()
{
	maxHeap<int> *myHeap = new maxHeap<int>(10);

	myHeap->push(2);
	myHeap->push(10);
	myHeap->push(15);
	myHeap->push(14);
	myHeap->push(20);

	std::cout << "Heap size " << myHeap->size() << std::endl;//5
	std::cout << "Heap top " << myHeap->top() << std::endl;  //20
	std::cout << *myHeap << std::endl << std::endl; //20 15 10 2 14

	myHeap->pop();
	myHeap->pop();
	std::cout << "Heap size " << myHeap->size() << std::endl;//3
	std::cout << "Heap top " << myHeap->top() << std::endl;  //14
	std::cout << *myHeap << std::endl << std::endl;; //14 2 10

	int arr[6];
	for (int i = 1; i < 6; ++i)
		arr[i] = i;
	myHeap->initialize(arr, 5);

	std::cout << "Heap size " << myHeap->size() << std::endl;//5
	std::cout << "Heap top " << myHeap->top() << std::endl;  //5
	std::cout << *myHeap << std::endl;  //5 4 3 1 2
	return 0;
}