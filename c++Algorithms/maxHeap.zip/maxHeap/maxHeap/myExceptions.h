#ifndef __MYEXCEPTIONS_H
#define __MYEXCEPTIONS_H

#include "main.h"

class illegalParameterValue
{
	std::string message;
public:
	illegalParameterValue(const char *theMessage = "Illegal Parameter Value") :message(theMessage) {}
	const char *what() {
		return message.c_str();
	}
};

class queueEmpty
{
	std::string message;
public:
	queueEmpty(string theMessage ="Invalid operation on empty queue") :message(theMessage){}
	const char *what() {
		return message.c_str();
	}
};
#endif __MYEXCEPTIONS_H