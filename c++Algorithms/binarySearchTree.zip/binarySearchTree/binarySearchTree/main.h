#ifndef __MAIN_H_

#include <iostream>
#include <utility>
#include <queue>

using std::cin;
using std::cout;
using std::endl;
using std::pair;
using std::queue;

#endif 