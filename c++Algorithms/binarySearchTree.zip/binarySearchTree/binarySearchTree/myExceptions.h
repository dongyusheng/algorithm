#ifndef __MYEXCEPTIONS_H_
#define __MYEXCEPTIONS_H_

#include "main.h"

class treeEmpty
{
public:
	treeEmpty(const char* theMessage = "The tree is empty") :message(theMessage) {

	}
	const char* what() { return this->message.c_str(); }
private:
	std::string message;
};

#endif __MYEXCEPTIONS_H_