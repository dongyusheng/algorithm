#include <iostream>
#include <sstream>
#include <iterator>
#include <algorithm>
#include <numeric>
#include <vector>
#include "illegalParamterValue.h"

template<typename T>
class linearList
{
public:
	virtual ~linearList() {};
	//�����Ա�Ϊ��ʱ����true
	virtual bool empty() const = 0;
	//�������Ա���Ԫ�ظ���
	virtual int size() const = 0;
	//��������theIndex��Ԫ��
	virtual T& get(int theIndex)const = 0;
	//����Ԫ��theElement��һ�γ���ʱ������
	virtual int indexOf(const T& theElement) const = 0;
	//ɾ������ΪtheIndex��Ԫ��
	virtual void earse(int theIndex) = 0;
	//��theElement�������Ա�������ΪtheIndex��λ����
	virtual void insert(int theIndex, const T& theElement) = 0;
	//�����Ա����������out
	virtual void output(ostream& out)const = 0;
};

template<typename T>
class vectorList :public linearList<T>
{
public:
	vectorList(int initialCapacity = 10);
	vectorList(const vectorList<T>& other);
	~vectorList();

	bool empty() const override;
	int size() const override;
	T& get(int theIndex)const override;
	int indexOf(const T& theElement) const override;
	void earse(int theIndex) override;
	void insert(int theIndex, const T& theElement) override;
	void output(ostream& out)const override;

	int capacity()const;

	typedef typename vector<T>::iterator iterator;
	iterator begin(){
		return element->begin();
	}
	iterator end() {
		return element->end();
	}
protected:
	void checkIndex(int theIndex)const;
protected:
	vector<T>* element;
};

int main()
{
	vectorList<int> s;
	s.insert(0,1);
	s.insert(1, 2);
	s.insert(2, 3);

	cout << "Size = "<<s.size()<<",Capacity = " <<s.capacity()<<endl;
	cout << "Index  0 value is " << s.get(0) << endl;
	cout << "Index  2 value is " << s.get(2) << endl;
	cout << "Number 1 index is " << s.indexOf(1) << endl;
	cout << "Number 3 index is "<<s.indexOf(2)<< endl;

	s.earse(0);

	cout << "Size = " << s.size() << ",Capacity = " << s.capacity() << endl;
	cout << "Index  0 value is " << s.get(0) << endl;
	cout << "Index  1 value is " << s.get(1) << endl;
	cout << "Number 1 index is " << s.indexOf(1) << endl;
	cout << "Number 3 index is " << s.indexOf(2) << endl;

	return 0;
}

template<typename T>
vectorList<T>::vectorList(int initialCapacity)
{
	if (initialCapacity < 1) {
		ostringstream s;
		s << "Size is " << initialCapacity << ",Must be >=1";
		throw illegalParamterValue(s.str().c_str());
	}

	element = new vector<T>;
	//��element����ΪinitialCapacity����С(Ҳ���Բ�ʹ������������湹���ʱ��ֱ�Ӹ�����СҲ��)
	element->reserve(initialCapacity);
}

template<typename T>
vectorList<T>::vectorList(const vectorList<T>& other)
{
	element = new vector<T>(*other.element);
}

template<typename T>
vectorList<T>::~vectorList()
{
	delete element;
}

template<typename T>
void vectorList<T>::checkIndex(int theIndex)const
{
	if ((theIndex < 0) || (theIndex >size()-1)) {
		ostringstream s;
		s << "List Size is " << size() << ",theIndex is " << theIndex;
		throw illegalParamterValue(s.str().c_str());
	}
}

template<typename T>
bool vectorList<T>::empty() const
{
	return element->empty();
}

template<typename T>
int vectorList<T>::size() const
{
	return element->size();
}

template<typename T>
int vectorList<T>::capacity()const
{
	return element->max_size();
}

template<typename T>
T& vectorList<T>::get(int theIndex)const
{
	checkIndex(theIndex);

	return element->at(theIndex);
}

template<typename T>
int vectorList<T>::indexOf(const T& theElement) const
{
	int  theIndex;
	theIndex =(find(element->begin(), element->end(), theElement) - element->begin());

	if (theIndex == element->size()) {
		return -1;
	}
	else
		return theIndex;
}

template<typename T>
void vectorList<T>::earse(int theIndex)
{
	checkIndex(theIndex);

	element->erase(begin()+theIndex);
}

template<typename T>
void vectorList<T>::insert(int theIndex, const T& theElement)
{
	if ((theIndex<0) || (theIndex > size())) {
		ostringstream s;
		s << "Size= " << size() << ",index=" << theIndex;
		throw illegalParamterValue(s.str().c_str());
	}

	element->insert(begin()+theIndex,theElement);
}

template<typename T>
void vectorList<T>::output(ostream& out)const
{
	copy(element->begin(), element->begin() + element->size(), ostream_iterator<T>(out, "  "));
}