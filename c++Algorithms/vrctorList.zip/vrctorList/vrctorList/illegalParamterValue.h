#ifndef __ILLEGALPARAMTERVALUE
#include <string>

using namespace std;

class illegalParamterValue
{
private:
	string message;
public:
	illegalParamterValue() : message("Illegal Paramter Value") {}
	illegalParamterValue(const char* s) :message(s) {}
	const char* what() {
		return message.c_str();
	}
};
#endif __ILLEGALPARAMTERVALUE