#ifndef __MAIN_H_
#define __MAIN_H_

#include <iostream>
#include <string>
#include <sstream>
#include <algorithm>
#include <functional>
#include <queue>
#include <exception>
#include <stdexcept>

using std::cout;
using std::cin;
using std::endl;
using std::string;
using std::max;
using std::pair;
using std::function;
using std::queue;

#endif __MAIN_H_