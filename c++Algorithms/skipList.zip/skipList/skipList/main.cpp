#include "skipList.h"


int main()
{
	skipList<int,int> *mySkipList = new skipList<int,int>(1000);

	mySkipList->insert(std::pair<int,int>(1,1));
	mySkipList->insert(std::pair<int, int>(2, 2));
	mySkipList->insert(std::pair<int, int>(3, 3));

	std::cout << "Current Size " << mySkipList->size() << std::endl;
	std::cout << "The key of 1 value is " << mySkipList->find(1)->second << std::endl;
	std::cout << "The key of 1 value is " << mySkipList->find(2)->second << std::endl;
	std::cout << "The key of 1 value is " << mySkipList->find(3)->second << std::endl;

	mySkipList->erase(1);
	std::cout << "Current Size " << mySkipList->size() << std::endl;
	//std::cout << "The key of 1 value is " << mySkipList->find(1)->second << std::endl;
	std::cout << "The key of 1 value is " << mySkipList->find(2)->second << std::endl;
	std::cout << "The key of 1 value is " << mySkipList->find(3)->second << std::endl;

	return 0;
}