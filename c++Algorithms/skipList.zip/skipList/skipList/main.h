#ifndef __MAIN_H_
#define __MAIN_H_

#include <iostream>
#include <stdio.h>
#include <sstream>
#include <string>
#include <utility>
#include <math.h>

using std::cout;
using std::cin;
using std::endl;
using std::string;
using std::pair;
using std::ceil;
using std::logf;

#endif __MAIN_H_