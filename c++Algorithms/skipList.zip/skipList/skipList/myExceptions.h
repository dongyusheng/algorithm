#ifndef __MYEXCEPTIONS__
#define __MYEXCEPTIONS__

#include "main.h"

class illegalParameter 
{
private:
	std::string message;
public:
	illegalParameter(const char* theMessage="Illegal Paramter"):message(theMessage){}
	const char* what() {
		return message.c_str();
	}
};

#endif __MYEXCEPTIONS__