#ifndef __MYEXCEPTIONS_H_
#define __MYEXCEPTIONS_H_

#include "main.h"

class illegalParameter
{
public:
	illegalParameter(const char *theMessage = "Illgeal Parameter") :message(theMessage) {}
	const char* what() {
		return message.c_str();
	}
private:
	std::string message;
};

class arrayTreeError
{
public:
	arrayTreeError(const char *theMessage="arrayTreeError"):message(theMessage){}
	const char* what() {
		return message.c_str();
	}
private:
	std::string message;
};

#endif __MYEXCEPTIONS_H_