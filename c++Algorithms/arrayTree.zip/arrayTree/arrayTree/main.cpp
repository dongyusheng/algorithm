#include "main.h"
#include "arrayTree.h"

int main()
{
	arrayTree<int> *myTree = new arrayTree<int>(3);
	myTree->append(1);
	myTree->append(2);
	myTree->append(3);
	myTree->append(4);
	myTree->append(5);
	myTree->append(6);
	myTree->append(7);
	myTree->append(8);
	myTree->append(9);
	myTree->append(10);

	std::cout << "Array Capacity:" << myTree->arrayCapacity() << std::endl;
	std::cout << "Array Len:" << myTree->arrayLen() << std::endl;
	std::cout << "tree Size:" << myTree->treeSize() << std::endl;

	std::cout << "1 left child is " << myTree->findLeftChild(1) << std::endl;
	std::cout << "4 right child is " << myTree->findRightChild(4) << std::endl;

	std::cout << "6 parent is " << myTree->findParent(6) << std::endl;
	std::cout << "10 parent is " << myTree->findParent(10) << std::endl;
	std::cout << std::endl;

	std::cout << "����:";
	myTree->theFirstOrderPrint(0);
	std::cout << std::endl;

	std::cout << "����:";
	myTree->inTheSequencePrint(0);
	std::cout << std::endl;
	
	std::cout << "����:";
	myTree->subsequentPrint(0);
	std::cout << std::endl;
	return 0;
}