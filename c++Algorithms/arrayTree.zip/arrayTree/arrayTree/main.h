#ifndef __MAIN_H_
#define __MAIN_H_

#include <iostream>
#include <sstream>
#include <string>
#include <algorithm>

using std::cout;
using std::cin;
using std::endl;
using std::string;

#endif __MAIN_H_