#ifndef __SORTEDCHAIN_H_
#define __SORTEDCHAIN_H_

#include "main.h"
#include "pairNode.h"
#include "dictionary.h"


template<class K,class E>
class sortedChain :public dictionary<K, E>
{
public:

	sortedChain();
	~sortedChain();
	bool empty()const override;
	int size()const override;
	std::pair<const K, E>* find(const K& theKey)const override;
	void erase(const K& theKey) override;
	void insert(const std::pair<const K, E>& thePair) override;
private:
	pairNode<K, E>* firstNode;
	int dSize;
};

template<class K, class E>
sortedChain<K, E>::sortedChain()
{
	this->firstNode = nullptr;
	this->dSize = 0;
}

template<class K, class E>
sortedChain<K, E>::~sortedChain()
{
	pairNode<K, E>* tempNode;
	while (this->firstNode) {
		tempNode = this->firstNode->next;
		delete this->firstNode;
		this->firstNode = tempNode;
	}
}

template<class K, class E>
bool sortedChain<K, E>::empty()const
{
	return this->dSize == 0;
}

template<class K, class E>
int sortedChain<K, E>::size()const
{
	return this->dSize;
}

template<class K, class E>
std::pair<const K, E>* sortedChain<K, E>::find(const K& theKey)const
{
	pairNode<K, E>* tempNode = this->firstNode;

	//�����ֵ�
	while ((tempNode != nullptr) && (tempNode->element.first != theKey))
		tempNode = tempNode->next;

	//����ҵ��˾ͷ���
	if ((tempNode != nullptr) && (tempNode->element.first == theKey))
		return &tempNode->element;

	//û���ҵ��ͷ��ؿ�
	return nullptr;
}

template<class K, class E>
void sortedChain<K, E>::erase(const K& theKey)
{
	pairNode<K, E>* eraseNode = this->firstNode;
	pairNode<K, E>* beforeEraseNode = nullptr;

	//�����ֵ�
	while ((eraseNode != nullptr) && (eraseNode->element.first < theKey))
	{
		beforeEraseNode = eraseNode;
		eraseNode = eraseNode->next;
	}

	//�ҵ��˾�ɾ��
	if ((eraseNode != nullptr) && (eraseNode->element.first == theKey))
	{
		//���ɾ������ͷ���
		if (eraseNode == this->firstNode){
			this->firstNode = eraseNode->next;
		}
		else{
			beforeEraseNode->next = eraseNode->next;
		}
		delete eraseNode;
		this->dSize--;
	}
}

template<class K, class E>
void sortedChain<K, E>::insert(const std::pair<const K, E>& thePair)
{
	pairNode<K, E>* afterInsertNode = this->firstNode;
	pairNode<K, E>* beforeInsertNode = nullptr;

	//�����ֵ�
	while ((afterInsertNode != nullptr) && (afterInsertNode->element.first < thePair.first))
	{
		beforeInsertNode = afterInsertNode;
		afterInsertNode = afterInsertNode->next;
	}

	//������Ѿ����ڣ�����ֵ
	if ((afterInsertNode != nullptr) && (afterInsertNode->element.first == thePair.first))
	{
		afterInsertNode->element.second = thePair.second;
		return;
	}

	//����������ڣ������½ڵ�
	pairNode<K, E>* insertNode = new pairNode<K,E>(thePair, afterInsertNode);
	if (beforeInsertNode == nullptr)
		this->firstNode = insertNode;
	else
		beforeInsertNode->next = insertNode;
	this->dSize++;
}


#endif __SORTEDCHAIN_H_