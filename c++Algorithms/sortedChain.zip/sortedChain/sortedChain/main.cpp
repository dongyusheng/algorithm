#include "sortedChain.h"

int main()
{
	sortedChain<int, char> *mySortedChain = new sortedChain<int, char>();
	
	mySortedChain->insert(std::pair<int, char>(1,'a'));
	mySortedChain->insert(std::pair<int, char>(2, 'b'));
	mySortedChain->insert(std::pair<int, char>(3, 'c'));

	std::cout << "Current size " << mySortedChain->size() << std::endl;

	mySortedChain->erase(1);
	std::cout << "Current size " << mySortedChain->size() << std::endl;

	std::pair<const int, char> *findPair;
	findPair = mySortedChain->find(2);
	std::cout << "Find success,key is " << findPair->first << ",value is " << findPair->second << std::endl;


	return 0;
}