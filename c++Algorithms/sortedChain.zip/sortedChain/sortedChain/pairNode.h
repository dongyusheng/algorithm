#ifndef __PAIRNODE_H_
#define __PAIRNODE_H_

#include "main.h"

template<class K,class E>
struct pairNode
{
	typedef pair<const K, E> pairType;
	pairType element;
	pairNode<K, E>* next;
	pairNode(const pairType& thePair):element(thePair){}
	pairNode(const pairType& thePair, pairNode<K, E>* theNext) :element(thePair)
	{
		next = theNext;
	}
};

#endif __PAIRNODE_H_